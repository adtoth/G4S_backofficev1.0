/*!
 * SAP UI development toolkit for HTML5 (SAPUI5/OpenUI5)
 * (c) Copyright 2009-2014 SAP AG or an SAP affiliate company. 
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
jQuery.sap.declare("sap.m.ToolbarSpacer");jQuery.sap.require("sap.m.library");jQuery.sap.require("sap.ui.core.Control");sap.ui.core.Control.extend("sap.m.ToolbarSpacer",{metadata:{library:"sap.m",properties:{"width":{type:"sap.ui.core.CSSSize",group:"Appearance",defaultValue:''}}}});sap.m.ToolbarSpacer.flexClass="sapMTBSpacerFlex";
